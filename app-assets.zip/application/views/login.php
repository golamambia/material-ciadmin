

    <!-- banner area stop -->

    <div class="inner_pagearea registerpage">
       <div class="container">
           <div class="register_box">
               <h2>Login with us</h2>
               <h3>Provide your credential</h3>
               <form action="" method="post">
                 
                  <div class="form-group">
                   <input type="email" class="form-control" placeholder="Email">
                 </div>
                 <div class="form-group">
                   <input type="password" class="form-control" placeholder="Password">
                 </div>
                 
                  <div class="form-group">
                   <input type="submit" class="btn btn-primary" value="Login">
                 </div>
                 
                 
               </form>
           </div>
       </div>
    </div>
   

