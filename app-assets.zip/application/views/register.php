

    <!-- banner area stop -->

    <div class="inner_pagearea registerpage">
       <div class="container">
           <div class="register_box">
               <h2>Sign Up for a Free Membership</h2>
               <h3>Create your Account, Its Free</h3>
               <form action="" method="post">
                 <div class="form-group">
                   <input type="text" class="form-control" placeholder="Full Name">
                 </div>
                  <div class="form-group">
                   <input type="email" class="form-control" placeholder="Email">
                 </div>
                 <div class="form-group">
                   <input type="text" class="form-control" name="quantity" id="quantity"  placeholder="Phone">
                 </div>
                  <div class="form-group">
                   <input type="submit" class="btn btn-primary" value="create account">
                 </div>
                 <h4>or Sign Up Using</h4>
                 <ul class="social_media">
                    <li><a href="#"><img src="<?php echo base_url();?>assets/front/images/facebook.png" alt="Facebook" title=""></a></li>
                    <li><a href="#"><img src="<?php echo base_url();?>assets/front/images/googleplus.png" alt="googleplus" title=""></a></li>
                 </ul>
                 <p>if you already have an account,  <a href="<?php echo base_url();?>login">Login here</a></p>
               </form>
           </div>
       </div>
    </div>
   

